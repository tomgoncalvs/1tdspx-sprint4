module.exports = {
    user: 'rm98571',
    password: '230997',
    connectString: 'oracle.fiap.com.br:1521/ORCL'
  };
  